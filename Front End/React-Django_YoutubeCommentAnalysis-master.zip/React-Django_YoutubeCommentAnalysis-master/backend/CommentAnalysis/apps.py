from django.apps import AppConfig


class CommentanalysisConfig(AppConfig):
    name = 'CommentAnalysis'
